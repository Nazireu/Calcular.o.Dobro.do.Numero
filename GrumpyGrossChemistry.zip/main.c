#include "stdio.h"

int main(void) {
  int numero;
  printf("Informe o número\n");
  scanf("%d",&numero);
  printf("O número %d dobrado é %d \n",numero,numero + numero);
  return 0;
}
